﻿// test1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

#pragma pack(2)
struct BMPFileHeader {
    uint16_t file_type{ 0x4D42 };          // File type always BM which is 0x4D42
    uint32_t file_size{ 0 };               // Size of the file (in bytes)
    uint16_t reserved1{ 0 };               // Reserved, always 0
    uint16_t reserved2{ 0 };               // Reserved, always 0
    uint32_t offset_data{ 0 };             // Start position of pixel data (bytes from the beginning of the file)
};


struct BMPInfoHeader {
    uint32_t size{ 0 };                      // Size of this header (in bytes)
    int32_t width{ 0 };                      // width of bitmap in pixels
    int32_t height{ 0 };                     // width of bitmap in pixels
                                             //       (if positive, bottom-up, with origin in lower left corner)                                    //       (if negative, top-down, with origin in upper left corner)
    uint16_t planes{ 1 };                    // No. of planes for the target device, this is always 1
    uint16_t bit_count{ 0 };                 // No. of bits per pixel
    uint32_t compression{ 0 };               // 0 or 3 - uncompressed. THIS PROGRAM CONSIDERS ONLY UNCOMPRESSED BMP images
    uint32_t size_image{ 0 };                // 0 - for uncompressed images
    int32_t x_pixels_per_meter{ 0 };
    int32_t y_pixels_per_meter{ 0 };
    uint32_t colors_used{ 0 };               // No. color indexes in the color table. Use 0 for the max number of colors allowed by bit_count
    uint32_t colors_important{ 0 };          // No. of colors used for displaying the bitmap. If 0 all colors are required
};

struct BMPColorHeader {
    uint32_t red_mask{ 0x00ff0000 };         // Bit mask for the red channel
    uint32_t green_mask{ 0x0000ff00 };       // Bit mask for the green channel
    uint32_t blue_mask{ 0x000000ff };        // Bit mask for the blue channel
    uint32_t alpha_mask{ 0xff000000 };       // Bit mask for the alpha channel
    uint32_t color_space_type{ 0x73524742 }; // Default "sRGB" (0x73524742)
    uint32_t unused[16]{ 0 };                // Unused data for sRGB color space 
};
#pragma pack()

class BMPReader {
public:
    //BMPReader(string path) {
    //    this->path = path;
    //}
    void openBMP(const string& fileName) {
        fin.open(fileName);
        if (!fin.is_open()){
            cerr << "Ошибка отркрытия файла: не существует такого файла";
            return;
        }

        fin.read((char*) & fileHeader, sizeof(fileHeader));
        fin.read((char*) & infoHeader, sizeof(infoHeader));

        fin.seekg(fileHeader.offset_data, fin.beg); // Переходим к массиву пикселей

        data.resize(infoHeader.width * infoHeader.height * infoHeader.bit_count / 8);
        if (infoHeader.width % 4 == 0 || infoHeader.bit_count == 32)fin.read((char*)data.data(), data.size());
        else {
            uint32_t row_width = infoHeader.width * infoHeader.bit_count / 8;
            int padding = (4 - row_width % 4) % 4;

            vector<uint8_t> padding_row(padding);

            for (int y = 0; y < infoHeader.height; y++) {
                fin.read((char*)(data.data() + row_width * y), row_width);
                fin.read((char*)padding_row.data(), padding_row.size());
            }
        }
    }
    void displayBMP() {
        int w = infoHeader.width, h = infoHeader.height;
        for (int i = 0; i < infoHeader.height; i++)
        {
            for (int j = 0; j < infoHeader.width; j++) {
                int pos = j + infoHeader.width * (infoHeader.height - i - 1);
                printPixel(pos);
            }
            cout << "\n";
        }
    }
    void closeBMP() {
        fin.close();
        data.clear();
    }

private:
    string path;
    BMPFileHeader fileHeader;
    BMPInfoHeader infoHeader;
    BMPColorHeader colorHeader;
    vector<unsigned char>data;
    ifstream fin;
    void printPixel(int pos) {
        int BPP = infoHeader.bit_count / 8; // bites per pixel;
        for (int i = 0; i < BPP; i++)
        {
            if (!data[pos * BPP + i]) {
                cout << "@";
                return;
            }
        }
        cout << ".";
    }
};

int main(int argc, char **argv)
{
    if (argc == 1)cerr << "No input file";
    else {
        BMPReader reader = BMPReader();
        reader.openBMP(argv[1]);
        reader.displayBMP();
        reader.closeBMP();
    }
    
}